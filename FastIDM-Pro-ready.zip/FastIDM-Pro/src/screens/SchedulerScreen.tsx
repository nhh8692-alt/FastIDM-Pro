import React from 'react';
import {
  View,
  Text,
  StyleSheet,
  Switch,
  TouchableOpacity,
  StatusBar,
  ScrollView,
} from 'react-native';
import { SafeAreaView } from 'react-native-safe-area-context';
import { Ionicons } from '@expo/vector-icons';
import { colors } from '../theme/colors';
import { useDownloadStore } from '../store/useDownloadStore';

export default function SchedulerScreen() {
  const { settings, updateSettings } = useDownloadStore();
  const { scheduler } = settings;

  const toggleScheduler = () => {
    updateSettings({
      scheduler: { ...scheduler, enabled: !scheduler.enabled },
    });
  };

  const toggleWifiOnly = () => {
    updateSettings({
      scheduler: { ...scheduler, wifiOnly: !scheduler.wifiOnly },
    });
  };

  return (
    <SafeAreaView style={styles.container} edges={['top']}>
      <StatusBar barStyle="light-content" />

      <View style={styles.header}>
        <Text style={styles.title}>زمان‌بندی هوشمند</Text>
        <Text style={styles.subtitle}>دانلود شبانه و مدیریت سرعت</Text>
      </View>

      <ScrollView contentContainerStyle={styles.content}>
        {/* Main Toggle */}
        <View style={styles.card}>
          <View style={styles.cardRow}>
            <Switch
              value={scheduler.enabled}
              onValueChange={toggleScheduler}
              trackColor={{ false: colors.border, true: colors.primary }}
              thumbColor="#fff"
            />
            <View style={styles.cardInfo}>
              <Text style={styles.cardTitle}>فعال‌سازی زمان‌بندی</Text>
              <Text style={styles.cardDesc}>
                دانلودها فقط در بازه زمانی مشخص اجرا شوند
              </Text>
            </View>
          </View>
        </View>

        {/* Time Range */}
        <View style={styles.card}>
          <Text style={styles.sectionLabel}>بازه زمانی</Text>
          <View style={styles.timeRow}>
            <View style={styles.timeBox}>
              <Text style={styles.timeValue}>
                {String(scheduler.startHour).padStart(2, '0')}:00
              </Text>
              <Text style={styles.timeLabel}>شروع</Text>
            </View>
            <Ionicons name="arrow-back" size={20} color={colors.textMuted} />
            <View style={styles.timeBox}>
              <Text style={styles.timeValue}>
                {String(scheduler.endHour).padStart(2, '0')}:00
              </Text>
              <Text style={styles.timeLabel}>پایان</Text>
            </View>
          </View>
        </View>

        {/* Options */}
        <View style={styles.card}>
          <View style={styles.optionRow}>
            <Switch
              value={scheduler.wifiOnly}
              onValueChange={toggleWifiOnly}
              trackColor={{ false: colors.border, true: colors.primary }}
              thumbColor="#fff"
            />
            <View style={styles.optionInfo}>
              <Ionicons name="wifi" size={20} color={colors.primary} />
              <Text style={styles.optionText}>فقط با Wi-Fi</Text>
            </View>
          </View>

          <View style={styles.divider} />

          <TouchableOpacity style={styles.optionRow}>
            <Ionicons name="chevron-back" size={18} color={colors.textMuted} />
            <View style={styles.optionInfo}>
              <Ionicons name="speedometer-outline" size={20} color={colors.primary} />
              <Text style={styles.optionText}>
                محدودیت سرعت:{' '}
                {scheduler.speedLimit === 0
                  ? 'بدون محدودیت'
                  : `${scheduler.speedLimit} KB/s`}
              </Text>
            </View>
          </TouchableOpacity>
        </View>

        {/* Info */}
        <View style={styles.infoCard}>
          <Ionicons name="information-circle" size={22} color={colors.accent} />
          <Text style={styles.infoText}>
            با فعال‌سازی زمان‌بندی، دانلودهای در صف به‌صورت خودکار در بازه شبانه شروع می‌شوند و در پایان بازه متوقف خواهند شد.
          </Text>
        </View>
      </ScrollView>
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: colors.background,
  },
  header: {
    paddingHorizontal: 20,
    paddingVertical: 12,
    alignItems: 'center',
  },
  title: {
    color: colors.text,
    fontSize: 20,
    fontWeight: '700',
  },
  subtitle: {
    color: colors.textSecondary,
    fontSize: 13,
    marginTop: 2,
  },
  content: {
    padding: 16,
    gap: 14,
  },
  card: {
    backgroundColor: colors.surface,
    borderRadius: 16,
    padding: 16,
    borderWidth: 1,
    borderColor: colors.border,
  },
  cardRow: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
  },
  cardInfo: {
    flex: 1,
    marginRight: 12,
  },
  cardTitle: {
    color: colors.text,
    fontSize: 15,
    fontWeight: '600',
    textAlign: 'right',
  },
  cardDesc: {
    color: colors.textSecondary,
    fontSize: 12,
    marginTop: 2,
    textAlign: 'right',
  },
  sectionLabel: {
    color: colors.textSecondary,
    fontSize: 13,
    marginBottom: 12,
    textAlign: 'right',
  },
  timeRow: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-around',
  },
  timeBox: {
    alignItems: 'center',
    backgroundColor: colors.surfaceLight,
    borderRadius: 12,
    paddingVertical: 14,
    paddingHorizontal: 28,
  },
  timeValue: {
    color: colors.primary,
    fontSize: 24,
    fontWeight: '700',
  },
  timeLabel: {
    color: colors.textSecondary,
    fontSize: 12,
    marginTop: 4,
  },
  optionRow: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
    paddingVertical: 6,
  },
  optionInfo: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 10,
  },
  optionText: {
    color: colors.text,
    fontSize: 14,
  },
  divider: {
    height: 1,
    backgroundColor: colors.border,
    marginVertical: 10,
  },
  infoCard: {
    flexDirection: 'row',
    backgroundColor: 'rgba(0, 229, 255, 0.08)',
    borderRadius: 14,
    padding: 14,
    gap: 10,
    borderWidth: 1,
    borderColor: 'rgba(0, 229, 255, 0.2)',
  },
  infoText: {
    flex: 1,
    color: colors.textSecondary,
    fontSize: 13,
    lineHeight: 20,
    textAlign: 'right',
  },
});
