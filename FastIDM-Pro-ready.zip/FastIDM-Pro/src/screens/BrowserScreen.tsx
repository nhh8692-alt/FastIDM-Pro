import React, { useState } from 'react';
import {
  View,
  Text,
  StyleSheet,
  TextInput,
  TouchableOpacity,
  ScrollView,
  StatusBar,
} from 'react-native';
import { SafeAreaView } from 'react-native-safe-area-context';
import { Ionicons } from '@expo/vector-icons';
import { colors } from '../theme/colors';

const SAMPLE_MEDIA = [
  { id: '1', title: 'ویدیو آموزشی React Native', quality: '1080p', type: 'video', size: '245 MB' },
  { id: '2', title: 'آهنگ پس‌زمینه', quality: 'MP3 320kbps', type: 'audio', size: '8.2 MB' },
  { id: '3', title: 'ویدیو کوتاه', quality: '720p', type: 'video', size: '45 MB' },
];

export default function BrowserScreen() {
  const [url, setUrl] = useState('https://');
  const [sniffed, setSniffed] = useState(false);

  const handleSniff = () => {
    setSniffed(true);
  };

  return (
    <SafeAreaView style={styles.container} edges={['top']}>
      <StatusBar barStyle="light-content" />

      <View style={styles.header}>
        <Text style={styles.title}>مرورگر هوشمند</Text>
        <Text style={styles.subtitle}>شناساگر خودکار مدیا</Text>
      </View>

      {/* URL Bar */}
      <View style={styles.urlBar}>
        <TouchableOpacity style={styles.goBtn} onPress={handleSniff}>
          <Ionicons name="search" size={20} color="#0B0F1A" />
        </TouchableOpacity>
        <TextInput
          style={styles.urlInput}
          value={url}
          onChangeText={setUrl}
          placeholder="آدرس سایت را وارد کنید..."
          placeholderTextColor={colors.textMuted}
          textAlign="right"
          autoCapitalize="none"
          keyboardType="url"
        />
        <Ionicons name="globe-outline" size={20} color={colors.textSecondary} />
      </View>

      {/* Quick Actions */}
      <View style={styles.quickActions}>
        <TouchableOpacity style={styles.quickBtn}>
          <Ionicons name="videocam" size={22} color={colors.primary} />
          <Text style={styles.quickText}>ویدیوها</Text>
        </TouchableOpacity>
        <TouchableOpacity style={styles.quickBtn}>
          <Ionicons name="musical-notes" size={22} color={colors.primary} />
          <Text style={styles.quickText}>آهنگ‌ها</Text>
        </TouchableOpacity>
        <TouchableOpacity style={styles.quickBtn}>
          <Ionicons name="document" size={22} color={colors.primary} />
          <Text style={styles.quickText}>فایل‌ها</Text>
        </TouchableOpacity>
        <TouchableOpacity style={styles.quickBtn}>
          <Ionicons name="images" size={22} color={colors.primary} />
          <Text style={styles.quickText}>تصاویر</Text>
        </TouchableOpacity>
      </View>

      <ScrollView style={styles.content} showsVerticalScrollIndicator={false}>
        {sniffed ? (
          <>
            <Text style={styles.sectionTitle}>مدیاهای شناسایی‌شده</Text>
            {SAMPLE_MEDIA.map((item) => (
              <View key={item.id} style={styles.mediaCard}>
                <View style={styles.mediaIcon}>
                  <Ionicons
                    name={item.type === 'video' ? 'videocam' : 'musical-notes'}
                    size={24}
                    color={colors.primary}
                  />
                </View>
                <View style={styles.mediaInfo}>
                  <Text style={styles.mediaTitle}>{item.title}</Text>
                  <Text style={styles.mediaMeta}>
                    {item.quality} • {item.size}
                  </Text>
                </View>
                <TouchableOpacity style={styles.downloadBtn}>
                  <Ionicons name="download" size={20} color="#0B0F1A" />
                </TouchableOpacity>
              </View>
            ))}
          </>
        ) : (
          <View style={styles.placeholder}>
            <Ionicons name="scan-outline" size={72} color={colors.textMuted} />
            <Text style={styles.placeholderTitle}>شناساگر مدیا آماده است</Text>
            <Text style={styles.placeholderText}>
              آدرس سایت را وارد کنید تا ویدیوها و آهنگ‌های در حال پخش به‌صورت خودکار شناسایی شوند
            </Text>
          </View>
        )}
      </ScrollView>
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: colors.background,
  },
  header: {
    paddingHorizontal: 20,
    paddingVertical: 12,
    alignItems: 'center',
  },
  title: {
    color: colors.text,
    fontSize: 20,
    fontWeight: '700',
  },
  subtitle: {
    color: colors.textSecondary,
    fontSize: 13,
    marginTop: 2,
  },
  urlBar: {
    flexDirection: 'row',
    alignItems: 'center',
    backgroundColor: colors.surface,
    marginHorizontal: 16,
    borderRadius: 14,
    paddingHorizontal: 14,
    paddingVertical: 10,
    gap: 10,
    borderWidth: 1,
    borderColor: colors.border,
  },
  urlInput: {
    flex: 1,
    color: colors.text,
    fontSize: 15,
  },
  goBtn: {
    backgroundColor: colors.primary,
    width: 36,
    height: 36,
    borderRadius: 10,
    alignItems: 'center',
    justifyContent: 'center',
  },
  quickActions: {
    flexDirection: 'row',
    justifyContent: 'space-around',
    paddingVertical: 20,
    paddingHorizontal: 16,
  },
  quickBtn: {
    alignItems: 'center',
    gap: 6,
  },
  quickText: {
    color: colors.textSecondary,
    fontSize: 12,
  },
  content: {
    flex: 1,
    paddingHorizontal: 16,
  },
  sectionTitle: {
    color: colors.text,
    fontSize: 16,
    fontWeight: '700',
    marginBottom: 12,
    textAlign: 'right',
  },
  mediaCard: {
    flexDirection: 'row',
    alignItems: 'center',
    backgroundColor: colors.surface,
    borderRadius: 14,
    padding: 14,
    marginBottom: 10,
    borderWidth: 1,
    borderColor: colors.border,
  },
  mediaIcon: {
    width: 48,
    height: 48,
    borderRadius: 12,
    backgroundColor: colors.surfaceLight,
    alignItems: 'center',
    justifyContent: 'center',
    marginLeft: 12,
  },
  mediaInfo: {
    flex: 1,
  },
  mediaTitle: {
    color: colors.text,
    fontSize: 14,
    fontWeight: '600',
    textAlign: 'right',
  },
  mediaMeta: {
    color: colors.textSecondary,
    fontSize: 12,
    marginTop: 2,
    textAlign: 'right',
  },
  downloadBtn: {
    backgroundColor: colors.primary,
    width: 40,
    height: 40,
    borderRadius: 12,
    alignItems: 'center',
    justifyContent: 'center',
  },
  placeholder: {
    alignItems: 'center',
    paddingTop: 60,
    paddingHorizontal: 30,
  },
  placeholderTitle: {
    color: colors.text,
    fontSize: 17,
    fontWeight: '600',
    marginTop: 16,
  },
  placeholderText: {
    color: colors.textSecondary,
    fontSize: 14,
    textAlign: 'center',
    marginTop: 8,
    lineHeight: 22,
  },
});
