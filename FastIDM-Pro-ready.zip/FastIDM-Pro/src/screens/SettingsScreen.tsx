import React from 'react';
import {
  View,
  Text,
  StyleSheet,
  Switch,
  TouchableOpacity,
  StatusBar,
  ScrollView,
} from 'react-native';
import { SafeAreaView } from 'react-native-safe-area-context';
import { Ionicons } from '@expo/vector-icons';
import { colors } from '../theme/colors';
import { useDownloadStore } from '../store/useDownloadStore';

export default function SettingsScreen() {
  const { settings, updateSettings } = useDownloadStore();

  return (
    <SafeAreaView style={styles.container} edges={['top']}>
      <StatusBar barStyle="light-content" />

      <View style={styles.header}>
        <Text style={styles.title}>تنظیمات</Text>
        <Text style={styles.subtitle}>پیکربندی موتور دانلود</Text>
      </View>

      <ScrollView contentContainerStyle={styles.content}>
        {/* Download Engine */}
        <Text style={styles.sectionTitle}>موتور دانلود</Text>
        <View style={styles.card}>
          <TouchableOpacity style={styles.row}>
            <Ionicons name="chevron-back" size={18} color={colors.textMuted} />
            <View style={styles.rowInfo}>
              <Text style={styles.rowLabel}>حداکثر رشته موازی</Text>
              <Text style={styles.rowValue}>{settings.maxThreads} رشته</Text>
            </View>
            <Ionicons name="git-network-outline" size={20} color={colors.primary} />
          </TouchableOpacity>

          <View style={styles.divider} />

          <View style={styles.row}>
            <Switch
              value={settings.autoResume}
              onValueChange={(v) => updateSettings({ autoResume: v })}
              trackColor={{ false: colors.border, true: colors.primary }}
              thumbColor="#fff"
            />
            <View style={styles.rowInfo}>
              <Text style={styles.rowLabel}>ادامه خودکار دانلود</Text>
            </View>
            <Ionicons name="play-forward-outline" size={20} color={colors.primary} />
          </View>

          <View style={styles.divider} />

          <View style={styles.row}>
            <Switch
              value={settings.notifyOnComplete}
              onValueChange={(v) => updateSettings({ notifyOnComplete: v })}
              trackColor={{ false: colors.border, true: colors.primary }}
              thumbColor="#fff"
            />
            <View style={styles.rowInfo}>
              <Text style={styles.rowLabel}>اعلان پس از تکمیل</Text>
            </View>
            <Ionicons name="notifications-outline" size={20} color={colors.primary} />
          </View>
        </View>

        {/* Appearance */}
        <Text style={styles.sectionTitle}>ظاهر</Text>
        <View style={styles.card}>
          <View style={styles.row}>
            <Switch
              value={settings.darkTheme}
              onValueChange={(v) => updateSettings({ darkTheme: v })}
              trackColor={{ false: colors.border, true: colors.primary }}
              thumbColor="#fff"
            />
            <View style={styles.rowInfo}>
              <Text style={styles.rowLabel}>تم تاریک</Text>
            </View>
            <Ionicons name="moon-outline" size={20} color={colors.primary} />
          </View>

          <View style={styles.divider} />

          <TouchableOpacity style={styles.row}>
            <Ionicons name="chevron-back" size={18} color={colors.textMuted} />
            <View style={styles.rowInfo}>
              <Text style={styles.rowLabel}>زبان</Text>
              <Text style={styles.rowValue}>فارسی</Text>
            </View>
            <Ionicons name="language-outline" size={20} color={colors.primary} />
          </TouchableOpacity>
        </View>

        {/* About */}
        <Text style={styles.sectionTitle}>درباره</Text>
        <View style={styles.card}>
          <View style={styles.row}>
            <View style={styles.rowInfo}>
              <Text style={styles.rowLabel}>نسخه برنامه</Text>
              <Text style={styles.rowValue}>1.0.0</Text>
            </View>
            <Ionicons name="information-circle-outline" size={20} color={colors.primary} />
          </View>
        </View>

        <View style={styles.footer}>
          <Text style={styles.footerBrand}>FastIDM Pro</Text>
          <Text style={styles.footerText}>دانلود منیجر هوشمند</Text>
        </View>
      </ScrollView>
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: colors.background,
  },
  header: {
    paddingHorizontal: 20,
    paddingVertical: 12,
    alignItems: 'center',
  },
  title: {
    color: colors.text,
    fontSize: 20,
    fontWeight: '700',
  },
  subtitle: {
    color: colors.textSecondary,
    fontSize: 13,
    marginTop: 2,
  },
  content: {
    padding: 16,
    paddingBottom: 40,
  },
  sectionTitle: {
    color: colors.textSecondary,
    fontSize: 13,
    fontWeight: '600',
    marginBottom: 8,
    marginTop: 8,
    textAlign: 'right',
    marginRight: 4,
  },
  card: {
    backgroundColor: colors.surface,
    borderRadius: 16,
    paddingHorizontal: 16,
    borderWidth: 1,
    borderColor: colors.border,
    marginBottom: 8,
  },
  row: {
    flexDirection: 'row',
    alignItems: 'center',
    paddingVertical: 14,
    gap: 12,
  },
  rowInfo: {
    flex: 1,
  },
  rowLabel: {
    color: colors.text,
    fontSize: 14,
    textAlign: 'right',
  },
  rowValue: {
    color: colors.textSecondary,
    fontSize: 12,
    textAlign: 'right',
    marginTop: 2,
  },
  divider: {
    height: 1,
    backgroundColor: colors.border,
  },
  footer: {
    alignItems: 'center',
    marginTop: 30,
  },
  footerBrand: {
    color: colors.primary,
    fontSize: 18,
    fontWeight: '800',
  },
  footerText: {
    color: colors.textMuted,
    fontSize: 13,
    marginTop: 4,
  },
});
