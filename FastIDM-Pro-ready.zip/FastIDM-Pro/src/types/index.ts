export type DownloadStatus = 'downloading' | 'completed' | 'paused' | 'queued' | 'failed';

export type MediaType = 'video' | 'audio' | 'file' | 'image';

export interface DownloadItem {
  id: string;
  title: string;
  url: string;
  size: number; // bytes
  downloaded: number; // bytes
  status: DownloadStatus;
  speed: number; // bytes per second
  threads: number;
  maxThreads: number;
  type: MediaType;
  progress: number; // 0-100
  createdAt: number;
  completedAt?: number;
  thumbnail?: string;
  remainingTime?: number; // seconds
}

export interface SchedulerConfig {
  enabled: boolean;
  startHour: number;
  endHour: number;
  wifiOnly: boolean;
  speedLimit: number; // KB/s, 0 = unlimited
}

export interface AppSettings {
  maxThreads: number;
  autoResume: boolean;
  darkTheme: boolean;
  language: 'fa' | 'en';
  scheduler: SchedulerConfig;
  notifyOnComplete: boolean;
}
