# FastIDM Pro - دانلود منیجر هوشمند

اپلیکیشن دانلود منیجر پیشرفته با تم دارک، پشتیبانی کامل فارسی و RTL.

## امکانات

- 🚀 شتاب‌دهنده چندرشته‌ای (تا ۳۲ رشته)
- 🌐 مرورگر اختصاصی با شناساگر مدیا
- ⏰ زمان‌بندی هوشمند دانلود شبانه
- 🎬 پخش‌کننده صوتی و تصویری داخلی
- ⚙️ تنظیمات پیشرفته موتور دانلود
- 🌙 تم دارک مدرن + RTL کامل

## نصب و اجرا

```bash
# نصب وابستگی‌ها
npm install

# اجرای پروژه
npx expo start
```

سپس با اپ **Expo Go** روی گوشی اسکن کنید یا شبیه‌ساز اندروید/iOS را باز کنید.

## ساخت APK

### روش پیشنهادی: Expo EAS Build

1. اکانت رایگان در [expo.dev](https://expo.dev) بسازید
2. در ترمینال پروژه:

```bash
npm install -g eas-cli
eas login
eas build:configure
eas build --platform android --profile preview
```

بعد از چند دقیقه لینک دانلود APK براتون میاد.

### پروفایل پیشنهادی (eas.json)

```json
{
  "build": {
    "preview": {
      "android": {
        "buildType": "apk"
      },
      "distribution": "internal"
    }
  }
}
```

## ساختار پروژه

```
src/
  components/   → کامپوننت‌های UI
  screens/      → صفحات اصلی
  store/        → مدیریت state با Zustand
  theme/        → رنگ‌ها و تم
  types/        → تایپ‌های TypeScript
  utils/        → توابع کمکی
```

## تکنولوژی‌ها

- React Native + Expo
- TypeScript
- React Navigation (Bottom Tabs)
- Zustand (State Management)
- Expo AV / FileSystem

---

ساخته شده با ❤️ برای کاربران فارسی‌زبان
