import React from 'react';
import {
  View,
  Text,
  StyleSheet,
  FlatList,
  TouchableOpacity,
  StatusBar,
} from 'react-native';
import { SafeAreaView } from 'react-native-safe-area-context';
import { Ionicons } from '@expo/vector-icons';
import { colors } from '../theme/colors';
import { useDownloadStore } from '../store/useDownloadStore';
import DownloadCard from '../components/DownloadCard';
import { formatSpeed } from '../utils/format';

const FILTERS = [
  { key: 'all', label: 'همه' },
  { key: 'downloading', label: 'در حال دانلود' },
  { key: 'completed', label: 'تکمیل شده' },
  { key: 'paused', label: 'متوقف شده' },
] as const;

export default function DownloadsScreen() {
  const {
    filter,
    setFilter,
    getFilteredDownloads,
    getStats,
    addDownload,
  } = useDownloadStore();

  const downloads = getFilteredDownloads();
  const stats = getStats();

  const handleNewDownload = () => {
    addDownload({
      title: 'دانلود جدید نمونه',
      url: 'https://example.com/file.zip',
      size: 500 * 1024 * 1024,
      status: 'downloading',
      threads: 8,
      maxThreads: 16,
      type: 'file',
    });
  };

  return (
    <SafeAreaView style={styles.container} edges={['top']}>
      <StatusBar barStyle="light-content" backgroundColor={colors.background} />

      {/* Header */}
      <View style={styles.header}>
        <View style={styles.headerTop}>
          <TouchableOpacity style={styles.headerBtn}>
            <Ionicons name="ellipsis-horizontal" size={22} color={colors.text} />
          </TouchableOpacity>
          <Text style={styles.appTitle}>FastIDM Pro</Text>
          <View style={styles.headerRight}>
            <TouchableOpacity style={styles.headerBtn}>
              <Ionicons name="search" size={22} color={colors.text} />
            </TouchableOpacity>
            <View style={styles.speedIndicator}>
              <Ionicons name="arrow-down" size={14} color={colors.primary} />
              <Text style={styles.speedText}>{formatSpeed(stats.totalSpeed)}</Text>
            </View>
          </View>
        </View>

        <Text style={styles.subtitle}>دانلود منیجر هوشمند</Text>

        {/* Stats Cards */}
        <View style={styles.statsRow}>
          <View style={styles.statCard}>
            <Text style={styles.statValue}>{formatSpeed(stats.totalSpeed)}</Text>
            <Text style={styles.statLabel}>سرعت لحظه‌ای</Text>
          </View>
          <View style={[styles.statCard, styles.statCardActive]}>
            <Text style={[styles.statValue, { color: colors.primary }]}>
              {stats.activeCount}
            </Text>
            <Text style={styles.statLabel}>در حال دانلود</Text>
          </View>
          <View style={styles.statCard}>
            <Text style={styles.statValue}>{stats.completedCount}</Text>
            <Text style={styles.statLabel}>تکمیل شده</Text>
          </View>
        </View>
      </View>

      {/* Filters */}
      <View style={styles.filters}>
        {FILTERS.map((f) => (
          <TouchableOpacity
            key={f.key}
            style={[styles.filterChip, filter === f.key && styles.filterChipActive]}
            onPress={() => setFilter(f.key)}
          >
            <Text
              style={[
                styles.filterText,
                filter === f.key && styles.filterTextActive,
              ]}
            >
              {f.label}
            </Text>
          </TouchableOpacity>
        ))}
      </View>

      {/* Queue Header */}
      <View style={styles.queueHeader}>
        <Text style={styles.queueTitle}>صف دانلودهای شما</Text>
        <TouchableOpacity>
          <Text style={styles.manageQueue}>مدیریت صف</Text>
        </TouchableOpacity>
      </View>

      {/* Downloads List */}
      <FlatList
        data={downloads}
        keyExtractor={(item) => item.id}
        renderItem={({ item }) => <DownloadCard item={item} />}
        contentContainerStyle={styles.list}
        showsVerticalScrollIndicator={false}
        ListEmptyComponent={
          <View style={styles.empty}>
            <Ionicons name="cloud-download-outline" size={64} color={colors.textMuted} />
            <Text style={styles.emptyText}>دانلودی وجود ندارد</Text>
          </View>
        }
      />

      {/* FAB */}
      <TouchableOpacity style={styles.fab} onPress={handleNewDownload}>
        <Ionicons name="add" size={28} color="#fff" />
        <Text style={styles.fabText}>دانلود جدید</Text>
      </TouchableOpacity>
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: colors.background,
  },
  header: {
    paddingHorizontal: 20,
    paddingBottom: 12,
  },
  headerTop: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
    marginBottom: 4,
  },
  headerRight: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 8,
  },
  headerBtn: {
    padding: 6,
  },
  appTitle: {
    color: colors.primary,
    fontSize: 20,
    fontWeight: '800',
  },
  subtitle: {
    color: colors.textSecondary,
    fontSize: 13,
    textAlign: 'center',
    marginBottom: 16,
  },
  speedIndicator: {
    flexDirection: 'row',
    alignItems: 'center',
    backgroundColor: 'rgba(0, 212, 170, 0.12)',
    paddingHorizontal: 8,
    paddingVertical: 4,
    borderRadius: 8,
    gap: 4,
  },
  speedText: {
    color: colors.primary,
    fontSize: 12,
    fontWeight: '600',
  },
  statsRow: {
    flexDirection: 'row',
    gap: 10,
  },
  statCard: {
    flex: 1,
    backgroundColor: colors.surface,
    borderRadius: 14,
    padding: 12,
    alignItems: 'center',
    borderWidth: 1,
    borderColor: colors.border,
  },
  statCardActive: {
    borderColor: colors.primary,
    backgroundColor: 'rgba(0, 212, 170, 0.08)',
  },
  statValue: {
    color: colors.text,
    fontSize: 16,
    fontWeight: '700',
    marginBottom: 2,
  },
  statLabel: {
    color: colors.textSecondary,
    fontSize: 11,
  },
  filters: {
    flexDirection: 'row',
    paddingHorizontal: 16,
    paddingVertical: 12,
    gap: 8,
  },
  filterChip: {
    paddingHorizontal: 14,
    paddingVertical: 7,
    borderRadius: 20,
    backgroundColor: colors.surface,
    borderWidth: 1,
    borderColor: colors.border,
  },
  filterChipActive: {
    backgroundColor: colors.primary,
    borderColor: colors.primary,
  },
  filterText: {
    color: colors.textSecondary,
    fontSize: 13,
    fontWeight: '500',
  },
  filterTextActive: {
    color: '#0B0F1A',
    fontWeight: '700',
  },
  queueHeader: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    paddingHorizontal: 20,
    marginBottom: 10,
  },
  queueTitle: {
    color: colors.text,
    fontSize: 16,
    fontWeight: '700',
  },
  manageQueue: {
    color: colors.primary,
    fontSize: 13,
  },
  list: {
    paddingHorizontal: 16,
    paddingBottom: 100,
  },
  empty: {
    alignItems: 'center',
    paddingTop: 60,
  },
  emptyText: {
    color: colors.textMuted,
    fontSize: 15,
    marginTop: 12,
  },
  fab: {
    position: 'absolute',
    bottom: 24,
    left: 20,
    right: 20,
    backgroundColor: colors.primary,
    borderRadius: 16,
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'center',
    paddingVertical: 16,
    gap: 8,
    elevation: 8,
    shadowColor: colors.primary,
    shadowOffset: { width: 0, height: 4 },
    shadowOpacity: 0.3,
    shadowRadius: 8,
  },
  fabText: {
    color: '#0B0F1A',
    fontSize: 16,
    fontWeight: '700',
  },
});
