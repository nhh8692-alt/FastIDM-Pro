import React, { useState } from 'react';
import {
  View,
  Text,
  StyleSheet,
  TouchableOpacity,
  FlatList,
  StatusBar,
} from 'react-native';
import { SafeAreaView } from 'react-native-safe-area-context';
import { Ionicons } from '@expo/vector-icons';
import { colors } from '../theme/colors';

const SAMPLE_LIBRARY = [
  {
    id: '1',
    title: 'آهنگ جدید - خواننده محبوب',
    type: 'audio',
    duration: '3:45',
    size: '10 MB',
  },
  {
    id: '2',
    title: 'آموزش برنامه نویسی پایتون',
    type: 'video',
    duration: '1:24:30',
    size: '1.2 GB',
  },
  {
    id: '3',
    title: 'پادکست تکنولوژی',
    type: 'audio',
    duration: '45:12',
    size: '42 MB',
  },
];

export default function PlayerScreen() {
  const [isPlaying, setIsPlaying] = useState(false);
  const [currentTrack, setCurrentTrack] = useState(SAMPLE_LIBRARY[0]);

  return (
    <SafeAreaView style={styles.container} edges={['top']}>
      <StatusBar barStyle="light-content" />

      <View style={styles.header}>
        <Text style={styles.title}>پخش‌کننده و گاوصندوق</Text>
        <Text style={styles.subtitle}>پخش مستقیم فایل‌های دانلودشده</Text>
      </View>

      {/* Now Playing Card */}
      <View style={styles.nowPlaying}>
        <View style={styles.cover}>
          <Ionicons
            name={currentTrack.type === 'video' ? 'videocam' : 'musical-notes'}
            size={40}
            color={colors.primary}
          />
        </View>
        <Text style={styles.trackTitle}>{currentTrack.title}</Text>
        <Text style={styles.trackMeta}>
          {currentTrack.duration} • {currentTrack.size}
        </Text>

        {/* Progress */}
        <View style={styles.progressBar}>
          <View style={[styles.progressFill, { width: '35%' }]} />
        </View>
        <View style={styles.timeRow}>
          <Text style={styles.timeText}>{currentTrack.duration}</Text>
          <Text style={styles.timeText}>1:18</Text>
        </View>

        {/* Controls */}
        <View style={styles.controls}>
          <TouchableOpacity>
            <Ionicons name="play-skip-back" size={28} color={colors.text} />
          </TouchableOpacity>
          <TouchableOpacity
            style={styles.playBtn}
            onPress={() => setIsPlaying(!isPlaying)}
          >
            <Ionicons
              name={isPlaying ? 'pause' : 'play'}
              size={32}
              color="#0B0F1A"
            />
          </TouchableOpacity>
          <TouchableOpacity>
            <Ionicons name="play-skip-forward" size={28} color={colors.text} />
          </TouchableOpacity>
        </View>

        <View style={styles.extraControls}>
          <TouchableOpacity>
            <Ionicons name="shuffle" size={22} color={colors.textSecondary} />
          </TouchableOpacity>
          <TouchableOpacity>
            <Ionicons name="repeat" size={22} color={colors.textSecondary} />
          </TouchableOpacity>
          <TouchableOpacity>
            <Ionicons name="phone-portrait-outline" size={22} color={colors.textSecondary} />
          </TouchableOpacity>
        </View>
      </View>

      {/* Library */}
      <Text style={styles.libraryTitle}>کتابخانه رسانه</Text>
      <FlatList
        data={SAMPLE_LIBRARY}
        keyExtractor={(item) => item.id}
        contentContainerStyle={styles.list}
        renderItem={({ item }) => (
          <TouchableOpacity
            style={[
              styles.libraryItem,
              currentTrack.id === item.id && styles.libraryItemActive,
            ]}
            onPress={() => setCurrentTrack(item)}
          >
            <View style={styles.libraryIcon}>
              <Ionicons
                name={item.type === 'video' ? 'videocam' : 'musical-notes'}
                size={20}
                color={colors.primary}
              />
            </View>
            <View style={styles.libraryInfo}>
              <Text style={styles.libraryName} numberOfLines={1}>
                {item.title}
              </Text>
              <Text style={styles.libraryMeta}>
                {item.duration} • {item.size}
              </Text>
            </View>
            {currentTrack.id === item.id && isPlaying && (
              <Ionicons name="bar-chart" size={18} color={colors.primary} />
            )}
          </TouchableOpacity>
        )}
      />
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: colors.background,
  },
  header: {
    paddingHorizontal: 20,
    paddingVertical: 12,
    alignItems: 'center',
  },
  title: {
    color: colors.text,
    fontSize: 20,
    fontWeight: '700',
  },
  subtitle: {
    color: colors.textSecondary,
    fontSize: 13,
    marginTop: 2,
  },
  nowPlaying: {
    backgroundColor: colors.surface,
    marginHorizontal: 16,
    borderRadius: 20,
    padding: 24,
    alignItems: 'center',
    borderWidth: 1,
    borderColor: colors.border,
  },
  cover: {
    width: 100,
    height: 100,
    borderRadius: 20,
    backgroundColor: colors.surfaceLight,
    alignItems: 'center',
    justifyContent: 'center',
    marginBottom: 16,
  },
  trackTitle: {
    color: colors.text,
    fontSize: 16,
    fontWeight: '700',
    textAlign: 'center',
  },
  trackMeta: {
    color: colors.textSecondary,
    fontSize: 13,
    marginTop: 4,
  },
  progressBar: {
    width: '100%',
    height: 4,
    backgroundColor: colors.progressBg,
    borderRadius: 2,
    marginTop: 20,
    overflow: 'hidden',
  },
  progressFill: {
    height: '100%',
    backgroundColor: colors.primary,
    borderRadius: 2,
  },
  timeRow: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    width: '100%',
    marginTop: 6,
  },
  timeText: {
    color: colors.textMuted,
    fontSize: 12,
  },
  controls: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 32,
    marginTop: 20,
  },
  playBtn: {
    width: 64,
    height: 64,
    borderRadius: 32,
    backgroundColor: colors.primary,
    alignItems: 'center',
    justifyContent: 'center',
  },
  extraControls: {
    flexDirection: 'row',
    gap: 40,
    marginTop: 16,
  },
  libraryTitle: {
    color: colors.text,
    fontSize: 16,
    fontWeight: '700',
    marginHorizontal: 20,
    marginTop: 20,
    marginBottom: 10,
    textAlign: 'right',
  },
  list: {
    paddingHorizontal: 16,
    paddingBottom: 20,
  },
  libraryItem: {
    flexDirection: 'row',
    alignItems: 'center',
    backgroundColor: colors.surface,
    borderRadius: 12,
    padding: 12,
    marginBottom: 8,
    borderWidth: 1,
    borderColor: colors.border,
  },
  libraryItemActive: {
    borderColor: colors.primary,
    backgroundColor: 'rgba(0, 212, 170, 0.08)',
  },
  libraryIcon: {
    width: 40,
    height: 40,
    borderRadius: 10,
    backgroundColor: colors.surfaceLight,
    alignItems: 'center',
    justifyContent: 'center',
    marginLeft: 12,
  },
  libraryInfo: {
    flex: 1,
  },
  libraryName: {
    color: colors.text,
    fontSize: 14,
    fontWeight: '600',
    textAlign: 'right',
  },
  libraryMeta: {
    color: colors.textSecondary,
    fontSize: 12,
    marginTop: 2,
    textAlign: 'right',
  },
});
