import React from 'react';
import { I18nManager, Platform } from 'react-native';
import { NavigationContainer, DarkTheme } from '@react-navigation/native';
import { createBottomTabNavigator } from '@react-navigation/bottom-tabs';
import { Ionicons } from '@expo/vector-icons';
import { StatusBar } from 'expo-status-bar';
import { GestureHandlerRootView } from 'react-native-gesture-handler';
import { SafeAreaProvider } from 'react-native-safe-area-context';

import DownloadsScreen from './src/screens/DownloadsScreen';
import BrowserScreen from './src/screens/BrowserScreen';
import SchedulerScreen from './src/screens/SchedulerScreen';
import PlayerScreen from './src/screens/PlayerScreen';
import SettingsScreen from './src/screens/SettingsScreen';
import { colors } from './src/theme/colors';

// Force RTL for Persian
if (!I18nManager.isRTL) {
  I18nManager.allowRTL(true);
  I18nManager.forceRTL(true);
}

const Tab = createBottomTabNavigator();

const navTheme = {
  ...DarkTheme,
  colors: {
    ...DarkTheme.colors,
    background: colors.background,
    card: colors.tabBar,
    text: colors.text,
    border: colors.border,
    primary: colors.primary,
  },
};

export default function App() {
  return (
    <GestureHandlerRootView style={{ flex: 1 }}>
      <SafeAreaProvider>
        <NavigationContainer theme={navTheme}>
          <StatusBar style="light" />
          <Tab.Navigator
            screenOptions={({ route }) => ({
              headerShown: false,
              tabBarStyle: {
                backgroundColor: colors.tabBar,
                borderTopColor: colors.border,
                borderTopWidth: 1,
                height: Platform.OS === 'ios' ? 88 : 68,
                paddingBottom: Platform.OS === 'ios' ? 28 : 10,
                paddingTop: 8,
              },
              tabBarActiveTintColor: colors.primary,
              tabBarInactiveTintColor: colors.inactiveTab,
              tabBarLabelStyle: {
                fontSize: 11,
                fontWeight: '600',
              },
              tabBarIcon: ({ focused, color, size }) => {
                let iconName: keyof typeof Ionicons.glyphMap = 'download';

                switch (route.name) {
                  case 'Downloads':
                    iconName = focused ? 'download' : 'download-outline';
                    break;
                  case 'Browser':
                    iconName = focused ? 'globe' : 'globe-outline';
                    break;
                  case 'Scheduler':
                    iconName = focused ? 'time' : 'time-outline';
                    break;
                  case 'Player':
                    iconName = focused ? 'play-circle' : 'play-circle-outline';
                    break;
                  case 'Settings':
                    iconName = focused ? 'settings' : 'settings-outline';
                    break;
                }

                return <Ionicons name={iconName} size={24} color={color} />;
              },
            })}
          >
            <Tab.Screen
              name="Downloads"
              component={DownloadsScreen}
              options={{ tabBarLabel: 'دانلودها' }}
            />
            <Tab.Screen
              name="Browser"
              component={BrowserScreen}
              options={{ tabBarLabel: 'مرورگر' }}
            />
            <Tab.Screen
              name="Scheduler"
              component={SchedulerScreen}
              options={{ tabBarLabel: 'زمان‌بندی' }}
            />
            <Tab.Screen
              name="Player"
              component={PlayerScreen}
              options={{ tabBarLabel: 'پخش‌کننده' }}
            />
            <Tab.Screen
              name="Settings"
              component={SettingsScreen}
              options={{ tabBarLabel: 'تنظیمات' }}
            />
          </Tab.Navigator>
        </NavigationContainer>
      </SafeAreaProvider>
    </GestureHandlerRootView>
  );
}
