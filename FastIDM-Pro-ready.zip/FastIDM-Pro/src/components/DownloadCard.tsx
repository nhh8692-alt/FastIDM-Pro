import React from 'react';
import {
  View,
  Text,
  StyleSheet,
  TouchableOpacity,
  I18nManager,
} from 'react-native';
import { Ionicons } from '@expo/vector-icons';
import { DownloadItem } from '../types';
import { colors } from '../theme/colors';
import { formatBytes, formatSpeed, formatTime, getMediaIcon } from '../utils/format';
import { useDownloadStore } from '../store/useDownloadStore';

interface Props {
  item: DownloadItem;
}

export default function DownloadCard({ item }: Props) {
  const { pauseDownload, resumeDownload, deleteDownload } = useDownloadStore();

  const isDownloading = item.status === 'downloading';
  const isCompleted = item.status === 'completed';
  const isPaused = item.status === 'paused';

  const handlePlayPause = () => {
    if (isDownloading) {
      pauseDownload(item.id);
    } else if (isPaused) {
      resumeDownload(item.id);
    }
  };

  return (
    <View style={styles.card}>
      {/* Header */}
      <View style={styles.header}>
        <View style={styles.iconContainer}>
          <Ionicons
            name={getMediaIcon(item.type) as any}
            size={22}
            color={colors.primary}
          />
        </View>

        <View style={styles.titleContainer}>
          <Text style={styles.title} numberOfLines={1}>
            {item.title}
          </Text>
          <Text style={styles.sizeText}>
            {formatBytes(item.downloaded)} از {formatBytes(item.size)}
          </Text>
        </View>

        <TouchableOpacity style={styles.moreBtn}>
          <Ionicons name="ellipsis-vertical" size={18} color={colors.textSecondary} />
        </TouchableOpacity>
      </View>

      {/* Progress Bar */}
      <View style={styles.progressContainer}>
        <View style={styles.progressBg}>
          <View
            style={[
              styles.progressFill,
              {
                width: `${item.progress}%`,
                backgroundColor: isCompleted
                  ? colors.success
                  : isPaused
                  ? colors.warning
                  : colors.primary,
              },
            ]}
          />
        </View>
      </View>

      {/* Stats Row */}
      <View style={styles.statsRow}>
        <View style={styles.statItem}>
          <Text style={styles.progressPercent}>{item.progress}%</Text>
        </View>

        {!isCompleted && (
          <View style={styles.statItem}>
            <Text style={styles.statText}>{item.threads} رشته فعال</Text>
          </View>
        )}

        {isDownloading && (
          <View style={styles.statItem}>
            <Text style={styles.statText}>
              {formatTime(item.remainingTime || 0)} باقی‌مانده
            </Text>
          </View>
        )}

        {isCompleted && (
          <View style={styles.statItem}>
            <Text style={[styles.statText, { color: colors.success }]}>
              تکمیل شده
            </Text>
          </View>
        )}
      </View>

      {/* Actions */}
      <View style={styles.actions}>
        {!isCompleted && (
          <TouchableOpacity style={styles.actionBtn} onPress={handlePlayPause}>
            <Ionicons
              name={isDownloading ? 'pause' : 'play'}
              size={20}
              color={colors.text}
            />
          </TouchableOpacity>
        )}

        {isCompleted && (
          <TouchableOpacity style={styles.actionBtn}>
            <Ionicons name="play" size={20} color={colors.primary} />
          </TouchableOpacity>
        )}

        <TouchableOpacity style={styles.actionBtn}>
          <Ionicons name="share-outline" size={20} color={colors.textSecondary} />
        </TouchableOpacity>

        <TouchableOpacity
          style={styles.actionBtn}
          onPress={() => deleteDownload(item.id)}
        >
          <Ionicons name="trash-outline" size={20} color={colors.error} />
        </TouchableOpacity>

        {isDownloading && (
          <View style={styles.speedBadge}>
            <Text style={styles.speedText}>{formatSpeed(item.speed)}</Text>
          </View>
        )}
      </View>
    </View>
  );
}

const styles = StyleSheet.create({
  card: {
    backgroundColor: colors.surface,
    borderRadius: 16,
    padding: 16,
    marginBottom: 12,
    borderWidth: 1,
    borderColor: colors.border,
  },
  header: {
    flexDirection: 'row',
    alignItems: 'center',
    marginBottom: 12,
  },
  iconContainer: {
    width: 42,
    height: 42,
    borderRadius: 12,
    backgroundColor: colors.surfaceLight,
    alignItems: 'center',
    justifyContent: 'center',
    marginLeft: 12,
  },
  titleContainer: {
    flex: 1,
  },
  title: {
    color: colors.text,
    fontSize: 15,
    fontWeight: '600',
    textAlign: 'right',
    marginBottom: 2,
  },
  sizeText: {
    color: colors.textSecondary,
    fontSize: 12,
    textAlign: 'right',
  },
  moreBtn: {
    padding: 4,
  },
  progressContainer: {
    marginBottom: 10,
  },
  progressBg: {
    height: 6,
    backgroundColor: colors.progressBg,
    borderRadius: 3,
    overflow: 'hidden',
  },
  progressFill: {
    height: '100%',
    borderRadius: 3,
  },
  statsRow: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    marginBottom: 12,
  },
  statItem: {
    flexDirection: 'row',
    alignItems: 'center',
  },
  progressPercent: {
    color: colors.primary,
    fontSize: 13,
    fontWeight: '700',
  },
  statText: {
    color: colors.textSecondary,
    fontSize: 12,
  },
  actions: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 8,
  },
  actionBtn: {
    width: 36,
    height: 36,
    borderRadius: 10,
    backgroundColor: colors.surfaceLight,
    alignItems: 'center',
    justifyContent: 'center',
  },
  speedBadge: {
    marginRight: 'auto',
    backgroundColor: 'rgba(0, 212, 170, 0.15)',
    paddingHorizontal: 10,
    paddingVertical: 4,
    borderRadius: 8,
  },
  speedText: {
    color: colors.primary,
    fontSize: 12,
    fontWeight: '600',
  },
});
