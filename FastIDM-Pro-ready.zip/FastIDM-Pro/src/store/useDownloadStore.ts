import { create } from 'zustand';
import { DownloadItem, DownloadStatus, AppSettings, SchedulerConfig } from '../types';

interface DownloadState {
  downloads: DownloadItem[];
  filter: 'all' | 'downloading' | 'completed' | 'paused';
  settings: AppSettings;
  
  // Actions
  addDownload: (item: Omit<DownloadItem, 'id' | 'createdAt' | 'progress' | 'downloaded' | 'speed' | 'remainingTime'>) => void;
  updateDownload: (id: string, updates: Partial<DownloadItem>) => void;
  pauseDownload: (id: string) => void;
  resumeDownload: (id: string) => void;
  deleteDownload: (id: string) => void;
  setFilter: (filter: DownloadState['filter']) => void;
  updateSettings: (settings: Partial<AppSettings>) => void;
  
  // Computed
  getFilteredDownloads: () => DownloadItem[];
  getStats: () => { totalSpeed: number; activeCount: number; completedCount: number };
}

const initialSettings: AppSettings = {
  maxThreads: 16,
  autoResume: true,
  darkTheme: true,
  language: 'fa',
  scheduler: {
    enabled: false,
    startHour: 1,
    endHour: 7,
    wifiOnly: true,
    speedLimit: 0,
  },
  notifyOnComplete: true,
};

// Sample data matching the screenshot
const sampleDownloads: DownloadItem[] = [
  {
    id: '1',
    title: 'آموزش برنامه نویسی پایتون کامل',
    url: 'https://example.com/python-course.mp4',
    size: 1200 * 1024 * 1024, // 1.2 GB
    downloaded: 467 * 1024 * 1024, // 467 MB
    status: 'downloading',
    speed: 1.2 * 1024 * 1024, // 1.2 MB/s
    threads: 16,
    maxThreads: 16,
    type: 'video',
    progress: 38,
    createdAt: Date.now() - 3600000,
    remainingTime: 180, // 3 minutes
  },
  {
    id: '2',
    title: 'آهنگ جدید - خواننده محبوب',
    url: 'https://example.com/song.mp3',
    size: 10 * 1024 * 1024, // 10 MB
    downloaded: 10 * 1024 * 1024,
    status: 'completed',
    speed: 0,
    threads: 8,
    maxThreads: 8,
    type: 'audio',
    progress: 100,
    createdAt: Date.now() - 7200000,
    completedAt: Date.now() - 3600000,
  },
  {
    id: '3',
    title: 'نرم افزار زیپ ۲۰۲۶',
    url: 'https://example.com/zip2026.zip',
    size: 753 * 1024 * 1024, // 753 MB
    downloaded: Math.floor(753 * 1024 * 1024 * 0.35),
    status: 'paused',
    speed: 0,
    threads: 8,
    maxThreads: 8,
    type: 'file',
    progress: 35,
    createdAt: Date.now() - 1800000,
  },
];

export const useDownloadStore = create<DownloadState>((set, get) => ({
  downloads: sampleDownloads,
  filter: 'all',
  settings: initialSettings,

  addDownload: (item) => {
    const newItem: DownloadItem = {
      ...item,
      id: Date.now().toString(),
      createdAt: Date.now(),
      progress: 0,
      downloaded: 0,
      speed: 0,
      remainingTime: undefined,
    };
    set((state) => ({ downloads: [newItem, ...state.downloads] }));
  },

  updateDownload: (id, updates) => {
    set((state) => ({
      downloads: state.downloads.map((d) =>
        d.id === id ? { ...d, ...updates } : d
      ),
    }));
  },

  pauseDownload: (id) => {
    set((state) => ({
      downloads: state.downloads.map((d) =>
        d.id === id ? { ...d, status: 'paused' as DownloadStatus, speed: 0 } : d
      ),
    }));
  },

  resumeDownload: (id) => {
    set((state) => ({
      downloads: state.downloads.map((d) =>
        d.id === id
          ? {
              ...d,
              status: 'downloading' as DownloadStatus,
              speed: 1.2 * 1024 * 1024,
            }
          : d
      ),
    }));
  },

  deleteDownload: (id) => {
    set((state) => ({
      downloads: state.downloads.filter((d) => d.id !== id),
    }));
  },

  setFilter: (filter) => set({ filter }),

  updateSettings: (newSettings) =>
    set((state) => ({
      settings: { ...state.settings, ...newSettings },
    })),

  getFilteredDownloads: () => {
    const { downloads, filter } = get();
    if (filter === 'all') return downloads;
    if (filter === 'downloading')
      return downloads.filter((d) => d.status === 'downloading' || d.status === 'queued');
    if (filter === 'completed')
      return downloads.filter((d) => d.status === 'completed');
    if (filter === 'paused')
      return downloads.filter((d) => d.status === 'paused');
    return downloads;
  },

  getStats: () => {
    const { downloads } = get();
    const active = downloads.filter((d) => d.status === 'downloading');
    const totalSpeed = active.reduce((sum, d) => sum + d.speed, 0);
    return {
      totalSpeed,
      activeCount: active.length,
      completedCount: downloads.filter((d) => d.status === 'completed').length,
    };
  },
}));
